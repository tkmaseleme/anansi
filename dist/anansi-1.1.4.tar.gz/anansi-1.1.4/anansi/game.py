from high_low import HighLow

game = HighLow()

game.play()